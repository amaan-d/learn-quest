export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12')
];

export const server_loads = [];

export const dictionary = {
		"/": [2],
		"/KG": [5],
		"/KG/Identifying_Counting_upto5": [6],
		"/KG/MLGF_upto5": [7],
		"/customizable-quests": [3],
		"/customizable-quests/questmaker": [4],
		"/message/QMfail": [8],
		"/message/quiznotfound": [9],
		"/message/success": [10],
		"/signin": [11],
		"/signup": [12]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
};

export { default as root } from '../root.svelte';