
<ol>
  <h1>Kindergarten - Math</h1>
  <li><a href="./KG/Identifying_Counting_upto5/" class="arrow"><i class="fas fa-arrow-right"></i>Indentifying and Counting Numbers (up to 5)</a></li>
  <li><a href="./KG/MLGF_upto5/" class="arrow"><i class="fas fa-arrow-right"></i>More, Less, Greater, Fewer (up to 5)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Indentifying and Counting Numbers (up to 10)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>More, Less, Greater, Fewer (up to 10)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Addition (up to 5)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Subtraction (up to 5)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Addition (up to 10)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Subtraction (up to 10)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Indentifying and Counting Numbers (up to 20)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Addition (up to 20)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Subtraction (up to 20)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Shapes (2D)</a></li>
  <li><a href="x.com" class="arrow"><i class="fas fa-arrow-right"></i>Shapes (3D)</a></li>
  <style>
    @import "https://fonts.googleapis.com/css2?family=Poppins&display=swap";

* {
  margin: 0;
  padding: 0;
}

html, body {
  display:flex;
  justify-content:center;
  align-items:center;
  font-family: 'Poppins';
  font-size: 1rem;
  line-height: 2;
  height: 100%;
  background-color: #221;
}

a {
  text-decoration: none;
  color: #ADD8E6;
  padding: 0px 5px;
}

li {
  color: #4FAF44;
  margin-left: 30px;
}

.arrow i {
  display: none;
}

.arrow {
  position:relative;
	display: block;
  color: #ADD8E6;
  border-radius: 8px;
}

.arrow:hover {
  cursor: pointer;
  background-color: rgba(236, 152, 56, .2);
}

.arrow:hover i { 
  display: block;
  position: absolute;
  top: 0.50em; 
  left: -3em;
}

h1 {
  color: white;
  text-align: center;
}

p, blockquote {
  color: white;
}


  </style>
</ol>